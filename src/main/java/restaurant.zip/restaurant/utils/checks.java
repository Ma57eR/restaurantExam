package restaurant.utils;

public class checks {
    public static void checkNameIfNullOrEmpty(String name, String message) {

    }
}
