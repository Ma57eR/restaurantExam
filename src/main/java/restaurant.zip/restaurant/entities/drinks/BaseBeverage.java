package restaurant.entities.drinks;

import restaurant.entities.drinks.interfaces.Beverages;

public abstract class BaseBeverage implements Beverages {
    private String name;
    private int count;
    private double price;
    private String brand;

    protected BaseBeverage(String name, int count, double price, String brand) {
        this.name = name;
        this.count = count;
        this.price = price;
        this.brand = brand;
        //TODO SETTERS
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getCounter() {
        return count;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getBrand() {
        return brand;
    }
}
